if (window.history && window.history.pushState) {
    window.history.pushState("", document.title, window.location.pathname);
  }
  