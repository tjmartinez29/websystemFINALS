from django.db import models

# Create your models here.
class Employee(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    contact = models.CharField(max_length=15)
    address = models.CharField(max_length=500)
    image = models.ImageField(upload_to='images/', blank=True, null=True)
    date_registered = models.DateField(null=True)

    class Meta:
        db_table = "tblemployee"

class Member(models.Model):
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    email = models.EmailField()
    
