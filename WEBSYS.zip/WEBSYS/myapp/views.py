from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from myapp.forms import EmployeeForm
from myapp.models import Employee
from django.utils import timezone
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages


def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Invalid username or password.')

    return render(request, 'login.html')


def logout_view(request):
    logout(request)
    return redirect('login')

def homepage(request):
    return render(request, 'members/homepage.html')

def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password1')
            user = authenticate(request, username=username,email=email, password=password)
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})


def addnew(request):
    if request.method == "POST":
        form = EmployeeForm(request.POST, request.FILES)
        if form.is_valid():
            employee = form.save(commit=False)
            employee.date_registered = timezone.localtime()  # Set the date_registered field with current datetime
            employee.save()
            return redirect('/')
    else:
        form = EmployeeForm()
    return render(request, 'add.html', {'form': form})


def index(request):
    employees = Employee.objects.all()
    return render(request, 'show.html', {'employees': employees})


def edit(request, id):
    employee = Employee.objects.get(id=id)
    form = EmployeeForm(instance=employee)
    return render(request, 'edit.html', {'employee': employee, 'form': form})


def update(request, id):
    employee = Employee.objects.get(id=id)
    form = EmployeeForm(request.POST, request.FILES, instance=employee)
    if form.is_valid():
        form.save()
        return redirect("/")
    return render(request, 'edit.html', {'employee': employee, 'form': form})


def destroy(request, id):
    employee = Employee.objects.get(id=id)
    employee.delete()
    return redirect("/")


def announcements(request):
    announcements = [
        {'title': 'Announcement 1', 'content': 'This is the content of announcement 1'},
    ]
    context = {
        'announcements': announcements
    }
    return render(request, 'announcements.html', context)
